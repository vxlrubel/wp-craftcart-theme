<?php

// directly access denied
defined('ABSPATH') || exit;

echo "</div> \n";
